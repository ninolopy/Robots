#ifndef __FILE_H
#define __FILE_H

void setupFile();
String loadFile(const char* filename);

#endif
